<?php 
ini_set("display_errors",1);
mysql_connect("localhost", "shailendra", "doordata") or die(mysql_error());
mysql_select_db("pdfexport");

if(isset($_REQUEST["SQL"]))
{

	$res=mysql_query($_REQUEST["SQL"]) or die(mysql_error());

}
else
{

	$res=mysql_query("select * from company LIMIT 0,10") or die(mysql_error());
	$row=mysql_fetch_array($res);
}
?>

<html>
 <body>
    <form method="post" name "frm">
	    <textarea name="SQL">
		
		</textarea>
		<input type="submit" value="RUN SQL">
	
	</form>
 </body>
</html>