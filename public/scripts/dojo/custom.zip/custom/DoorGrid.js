dojo.provide("custom.DoorGrid");
dojo.require("ginger.Grid");
dojo.require("custom.widgets.BratiliusGrid");

dojo.declare("custom.DoorGrid", custom.widgets.BratiliusGrid, {
	
});